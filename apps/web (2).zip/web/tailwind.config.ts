import shared from '../../packages/config/tailwind-config'
export default shared
